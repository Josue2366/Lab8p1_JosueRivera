/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab8p1_josuerivera;

import java.util.ArrayList;

/**
 *
 * @author josue
 */
public class Game {
    int [][] mat;
    int [][] mat2;
    ArrayList<String> lista;
    int rondas;

    public Game() {
    }

    public int[][] getMat() {
        return mat;
    }

    public void setMat(int[][] mat) {
        this.mat = mat;
    }

    public int[][] getMat2() {
        return mat2;
    }

    public void setMat2(int[][] mat2) {
        this.mat2 = mat2;
    }

    public ArrayList<String> getLista() {
        return lista;
    }

    public void setLista(ArrayList<String> lista) {
        this.lista = lista;
    }

    public int getRondas() {
        return rondas;
    }

    public void setRondas(int rondas) {
        this.rondas = rondas;
    }
    public void jugar(int rondas){
        
        for (int i = 0; i < rondas; i++) {
          Print(nextgen());
        }
    }
    public ArrayList<String> nextgen(){
        ArrayList<String> list = new ArrayList<>();
        int [][] temp = mat;
        int cont = 0;
        for (int i = 1; i < temp.length-2; i++) {
            for (int j = 1; j < temp.length-2; j++) {
                if(temp[i][j] == 1){
                    if(temp[i-1][j-1]==1){
                        cont++;
                    }
                    if(temp[i-1][j]==1){
                        cont++;
                    }
                    if(temp[i-1][j+1]==1){
                        cont++;
                    }
                    if(temp[i][j-1]==1){
                        cont++;
                    }
                    if(temp[i][j+1]==1){
                        cont++;
                    }
                    if(temp[i+1][j-1]==1){
                        cont++;
                    }
                    if(temp[i+1][j]==1){
                        cont++;
                    }
                    if(temp[i+1][j+1]==1){
                        cont++;
                    }
                    if (cont == 2){
                        mat2[i][j] = 1;
                        cont=0;
                    }else{
                        mat2[i][j] = 0;
                        cont=0;
                    }
                }
                else if(temp[i][j] == 0){
                    if(temp[i-1][j-1]==1){
                        cont++;
                    }
                    if(temp[i-1][j]==1){
                        cont++;
                    }
                    if(temp[i-1][j+1]==1){
                        cont++;
                    }
                    if(temp[i][j-1]==1){
                        cont++;
                    }
                    if(temp[i][j+1]==1){
                        cont++;
                    }
                    if(temp[i+1][j-1]==1){
                        cont++;
                    }
                    if(temp[i+1][j]==1){
                        cont++;
                    }
                    if(temp[i+1][j+1]==1){
                        cont++;
                    }
                    if (cont == 3){
                        mat2[i][j] = 1;
                        cont=0;
                    }else{
                        mat2[i][j] = 0;
                        cont=0;
                    }
                }
            }
               
        }
        for (int i = 0; i < mat2.length; i++) {
            for (int j = 0; j < mat2.length; j++) {
                if (mat2[i][j] == 1){
                    list.add( Integer.toString(i)+":"+Integer.toString(j));
                }
            }
        }
        mat = mat2;
        return list;
    }
    public void Print(ArrayList<String> list){
        int [][] prin = new int [10][10];
        String temp ;
        int x;
        int y;
        System.out.println(list);
        for (int i = 0; i < list.size(); i++) {
            temp = list.get(i);
            x = Character.getNumericValue(temp.charAt(0));
            y = Character.getNumericValue(temp.charAt(2));
            prin [x][y]= 1;
        }
        for (int i = 0; i < prin.length; i++) {
            for (int j = 0; j < prin.length; j++) {
                if(prin[i][j] == 1){
                    continue;
                }
                else{
                    prin[i][j]=0;
                }
                
            }
            
        }
        for (int i = 0; i < prin.length; i++) {
            for (int j = 0; j < prin.length; j++) {
                System.out.print("["+prin[i][j]+"]");
            }
            System.out.println("");
            
        }
    }
}
