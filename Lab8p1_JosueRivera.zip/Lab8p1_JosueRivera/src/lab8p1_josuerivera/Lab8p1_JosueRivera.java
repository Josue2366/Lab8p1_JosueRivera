/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab8p1_josuerivera;
import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
/**
 *
 * @author josue
 */
public class Lab8p1_JosueRivera {
    static Scanner sc = new Scanner(System.in);
    static Random rand = new Random();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("/////menu/////");
        System.out.println("1. ");
        System.out.println("2. Salir");
        System.out.println("Ingrese su opcion");
        int opcion = sc.nextInt();
        while (opcion != 2 && opcion != 1){
            System.out.println("opcion invalida, ingrese su opcion otra vez");
            opcion = sc.nextInt();
        }
        while(opcion == 1){
            switch(opcion){
                case 1:
                    Game G = new Game();
                    System.out.println("Ingrese el numero de rondas:");
                    int rondas = sc.nextInt();
                    G.setRondas(rondas);
                    int mat [][] = new int [10][10];
                    int mat2 [][] = new int [10][10];
                    G.setMat2(mat2);
                    ArrayList<String> lista = new ArrayList<>();
                    mat = llenar_mat(mat,mat2,lista);
                    G.setMat(mat);
                    lista = llenar_lista(lista,mat);
                    G.setLista(lista);
                    G.jugar(rondas);
                    System.out.println("ok1");
                    break;
            }
            System.out.println("/////menu/////");
            System.out.println("1. ");
            System.out.println("2. Salir");
            System.out.println("Ingrese su opcion");
            opcion = sc.nextInt();
            while (opcion != 2 && opcion != 1){
                System.out.println("opcion invalida, ingrese su opcion otra vez");
                opcion = sc.nextInt();
            }
        }
        // TODO code application logic here
    
        
    }
    public static ArrayList<String> llenar_lista(ArrayList<String> lista, int [][] x){
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x.length; j++) {
                if (x[i][j] == 1){
                    lista.add( Integer.toString(i)+":"+Integer.toString(j));
                }
            }
            
        }
        return lista;
    }
    public static int [][] llenar_mat(int [][] x,int [][] y, ArrayList<String> lista){
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x.length; j++) {
                if (i == 0 || i == 9 || j == 0 || j==9){
                    x [i][j] = 0;    
                }
                else{
                    x[i][j] = rand.nextInt((1-0)+1)+0;
                    if (x[i][j] == 1){
                        lista.add( Integer.toString(i)+":"+Integer.toString(j));
                    }
                }
            }
            
        }
        
        System.out.println(lista);
        imprimirmat(x);
        return x;
        
    }
    public static void imprimirmat(int [][] x){
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x.length; j++) {
                System.out.print("["+x[i][j]+"]");
            }
            System.out.println("");
            
        }
    }
    
}
